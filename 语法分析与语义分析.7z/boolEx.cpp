#include "boolEx.h"

RetType BOOL_::E()
{
    RetType E_ret;
    int E_codeBegin = fourTuples.size();
    PL("E", "IE'");
    list<int> E1_true;
    list<int> E1_false;
    list<int> E2_true;
    list<int> E2_false;
    RetType E1_ret = I();
    RetType E2_ret;
    switch (tkid())
    {
    case flag::OR: {
        curPos++;
        E2_ret = E();
        int E2_codeBegin = E2_ret.codeBegin;
        E1_true = E1_ret.turelist;
        E1_false = E1_ret.falselist;
        E2_true = E2_ret.turelist;
        E2_false = E2_ret.falselist;
        backPatch(E1_false, E2_codeBegin);
        E1_true.merge(E2_true);
        E_ret.codeBegin = E_codeBegin;
        E_ret.turelist = E1_true;
        E_ret.falselist = E2_false;
        return E_ret;
        break;
    }
    default:
        break;
    }
    return E1_ret;
}

RetType BOOL_::E_()
{
    switch (tkid())
    {
    case flag::OR: {
        PL("E'", "orIE'");
        curPos++;
        I();
        E_();
        break;
    }
    default:
        PL("E'", "��");
        break;
    }
    return RetType();
}

RetType BOOL_::I()
{
    int codeBegin = fourTuples.size();
    PL("I", "DI'");
    RetType E1 = D();
    E1.codeBegin = codeBegin;
    if (tkid() == flag::AND) {
        curPos++;
        RetType E2 = I();
        backPatch(E1.turelist, E2.codeBegin);
        E2.falselist.merge(E1.falselist);
        RetType E_ret;
        E_ret.falselist = E2.falselist;
        E_ret.turelist = E2.turelist;
        E_ret.codeBegin = codeBegin;
        return E_ret;
    }
    return E1;
}

RetType BOOL_::I_()
{
    switch (tkid())
    {
    case flag::AND: {
        PL("I'", "andDI'");
        curPos++;
        D();
        I_();
        break;
    }
    default:
        PL("I'", "��");
        break;
    }
    return RetType();
}

RetType BOOL_::D()
{
    RetType E_ret;
    int codeBegin = fourTuples.size();
    switch (tkid())
    {
    case flag::NOT: {
        PL("D", "notD");
        curPos++;
        RetType E1 = D();
        E_ret.falselist = E1.turelist;
        E_ret.turelist = E1.falselist;
        E_ret.codeBegin = E1.codeBegin;
        break;
    }
    default:
        PL("D", "Q");
        E_ret = Q();
        break;
    }
    return E_ret;
}

RetType BOOL_::Q()
{
    switch (tkid())
    {
    case flag::TRUE: {
        curPos++;
        RetType ret;
        ret.codeBegin = fourTuples.size();
        ret.turelist.push_back(ret.codeBegin);
        emit("j", "-", "-", "?");
        PL("Q", "true");
    }
    case flag::FALSE: {
        curPos++; 
        RetType ret;
        ret.codeBegin = fourTuples.size();
        ret.falselist.push_back(ret.codeBegin);
        emit("j", "-", "-", "?");
        PL("Q", "false");
    }
    case flag::ID: {
        PL("Q", "math::E Q' ");
        RetType E1;
        E1.codeBegin = fourTuples.size();
        E1 = MATH_::E();
        
        if (53 <= tkid() && tkid() <= 58) {
            PL("Q'", "rop math::E");
            RetType rop =Rop();
            RetType E2 = MATH_::E();
			emit(rop.value, E1.name, E2.name,/*"?"*/ to_string(fourTuples.size() + 2));
            E1.turelist.push_back(fourTuples.size());
            emit("j", "-", "-", "?");
            E1.falselist.push_back(fourTuples.size());
        }
        else {
            emit("jz0", E1.name, "-", to_string(fourTuples.size() + 3));
            E1.turelist.push_back(fourTuples.size());
            emit("j", "-", "-", "?");
            E1.falselist.push_back(fourTuples.size());
        }
        return E1;
        break;
    }
    case flag::L_PARENTHESIS: {
        PL("Q", "(E)");
        if (tkid() == flag::L_PARENTHESIS)curPos++;
        else error();
		RetType ret = E();
        if (tkid() == flag::R_PARENTHESIS)curPos++;
        else error();
        return ret;
        break;
    }
    default:
        error();
        break;
    }
    return RetType();
}

RetType BOOL_::Rop()
{
    RetType ret;
    switch (tkid())
    {
    case 53: {
        curPos++;
        PL("Rop", "<");
        ret.value = "j<";
        break;
    }
    case 54: {
        curPos++;
        PL("Rop", "<=");
        ret.value = "j<=";
        break;
    }
    case 55: {
        curPos++;
        PL("Rop", "<>");
        ret.value = "j<>";
        break;
    }
    case 56: {
        curPos++;
        PL("Rop", "=");
        ret.value = "j=";
        break;
    }
    case 57: {
        curPos++;
        PL("Rop", ">");
        ret.value = "j>";
        break;
    }
    case 58: {
        curPos++;
        PL("Rop", ">=");
        ret.value = "j>=";
        break;
    }
    default:
        error();
        break;
    }
    return ret;
}
