#pragma once
#include "mathEx.h"
#include "boolEx.h"
#include "statement.h"
//#include "boolEx.h"
#ifndef FUNC_H_
#define FUNC_H_
namespace FUNC_ {
	void program();
	RetType varDeclaration();
	RetType varDefinition();
	RetType idTable();
	RetType type();

}
#endif // !FUNC_H_

