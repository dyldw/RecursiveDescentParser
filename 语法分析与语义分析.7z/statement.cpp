#include "statement.h"

RetType STATE_::statementTable()
{
    RetType S = statement();
    backPatch(S.chain, fourTuples.size());
    if (tkid() == flag::SEMICOLON) {
        curPos++;
        statementTable();
    }
    return RetType();
}

RetType STATE_::statement()
{
    RetType ret;
    switch (tkid())
    {
    case flag::ID: {
        PL("statement", "assignStatement");
        ret = assignStatement();
        break;
    }
    case flag::IF: {
        PL("statement", "ifStatement");
        ret = ifStatement();
        break;
    }
    case flag::WHILE: {
        PL("statement", "whileStatement");
        ret = whileStatement();
        break;
    }
    case flag::REPEAT: {
        PL("statement", "repeatStatement");
        ret = repeatStatement();
        break;
    }
    case flag::BEGIN: {
        PL("statement", "compoundStatement");
        ret = compoundStatement();
        break;
    }
    default:
        error();
        break;
    }
    return ret;
}

RetType STATE_::assignStatement()
{
    RetType rT;
    rT.codeBegin = fourTuples.size();
    string varnameE;
    string varname;
    if (tkid() == flag::ID) {
        varname = tkva();
        curPos++;
        if (tkid() == flag::ASSIGN) {
            curPos++;
            varnameE = MATH_::E().name;
            emit(":=", varnameE, "-", varname);
            rT.name = varname;
        }
        else error();
    }
    else error();

    return rT;
}

RetType STATE_::ifStatement()
{
    RetType S;
    int codebegin = fourTuples.size();
    if (tkid() == flag::IF) {
        curPos++;
        RetType E = BOOL_::E();
        list<int> backE_falselist = E.falselist;
        S.chain.merge(E.falselist);
        if (tkid() == flag::THEN) {
            curPos++;
            RetType S1 = statement();
            backPatch(E.turelist, S1.codeBegin);
            S.chain.merge(S1.chain);
            if (tkid() == flag::ELSE) {
                curPos++;
                emit("j", "-", "-", "?");
                S.chain.clear();
                S.chain.merge(S1.chain);
                S.chain.push_back(fourTuples.size());
                RetType S2 = statement();
                S.chain.merge(S2.chain);
                backPatch(backE_falselist, S2.codeBegin);
                
            }
            return S;
        }
        else error();
    }
    else error();
    return S;
}

RetType STATE_::whileStatement()
{
    RetType W;
    W.codeBegin = fourTuples.size();
    if (tkid() == flag::WHILE) {
        curPos++;
        RetType E = BOOL_::E();
        backPatch(E.turelist, fourTuples.size());
        W.chain = E.falselist;
        if (tkid() == flag::DO) {
            curPos++;
            RetType S = statement();
            backPatch(S.chain, W.codeBegin);
            emit("j", "-", "-", to_string(W.codeBegin));
        }
        else error();
    }
    else error();
    return W;
}

RetType STATE_::repeatStatement()
{
    RetType ret;
    ret.codeBegin = fourTuples.size();
    if (tkid() == flag::REPEAT) {
        curPos++;
        RetType S = statement();
        if (tkid() == flag::UNTIL) {
            curPos++;
            RetType E = BOOL_::E();
            S.chain = E.turelist;
            backPatch(E.falselist, ret.codeBegin);
        }
        else error();
    }
    else error();

    return ret;
}

RetType STATE_::compoundStatement()
{
    if (tkid() == flag::BEGIN) {
        curPos++;
        statementTable();
        if (tkid() == flag::END) {
            curPos++;
        }
        else error();
    }
    return RetType();
}
