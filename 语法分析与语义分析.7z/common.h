#pragma once
#ifndef COMMON_H_
#define COMMON_H_

#pragma warning(disable:26812)	
#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <tuple>
#include <map>
#include <list>
using namespace std;
#define PL(s1,s2) {/*cout << #s1 << " --> " << #s2 <<"\n";*/}
#define error() { cout<<"�﷨����"<<__func__<<" line��"<<__LINE__<<"\n"; system("pause"); }
struct Token {
	int key;
	string value;
};

class RetType {
public:
	list<int> turelist;
	list<int> falselist;
	list<int> chain;
	int codeBegin;
	string name;
	string value;
	RetType() : codeBegin(-1), name(""),value("") {};
};

enum flag {TERM = 0,
	AND = 1, ARRY, BEGIN, BOOL, CALL, CASE, CHAR, CONSTANT, DIM, DO
	, ELSE, END, FALSE, FOR, IF, INPUT, INT, NOT, OF, OR, OUTPUT, PROCEDURE, PROGRAM, READ, REAL
	, REPEAT, SET, STOP, THEN, TO, TRUE, UNTIL, VAR, WHILE, WRITE, ID/* ��ʶ�� */, INTEGER, CHARACTER, L_PARENTHESIS/* ( */
	, R_PARENTHESIS, /* * */ASTERISK, RIGHT_ASTERISK_SLASH/* /* */, ADD, COMMA/* , */, SUB, DOT/* . */, DOTDOT/* .. */, SLASH/* / */
	, LEFT_ASTERISK_SLASH/* /* */, COLON/* : */, ASSIGN, SEMICOLON/* ; */, LESS/*<*/
	, LESS_EQUAL, LESS_OR_GREATER/* <>*/, EQUAL, GREATER, GREATER_EQUAL, LEFT_SQUARE_BRACKET/* [ */
	, RIGHT_SQUARE_BRACKET/* ] */
	, ARITHMETIC_EXPRESSION
};

typedef vector<Token> Tokens;
typedef array<string, 4> FourTuple;
typedef vector<FourTuple> FourTuples;
typedef int RecordType;
typedef map<string, RecordType> SymbolTable;
extern int curPos;
extern FourTuples fourTuples;
extern SymbolTable table;
extern Tokens tokens;
extern Tokens tokens_4;
extern Tokens tokens_5;
Token Tk();
flag tkid();
string tkva();
void backPatch(list<int> ls,int pos);
bool tkis(Token const& tk, initializer_list<flag> flags);
int emit(string op = "-", string arg1 = "-", string arg2 = "-", string result = "-");
int showTuples();
bool addVar(string name,int value = 0);
string tmpVar();
#endif // !COMMON_H_
