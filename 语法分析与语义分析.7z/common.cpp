#include "common.h"
int curPos;
int tmpTimes = 1;
#define test 1
FourTuples fourTuples;
SymbolTable table;

Tokens tokens_4{

{23,"program"},{36,"example4"},{52,";"},{33,"var"}
,{36,"A"},{44,","},{36,"B"},{44,","},{36,"C"},{44,","},{36,"D"}
,{50,":"},{17,"integer"},{52,";"},{3,"begin"},{36,"A"},{51,":="},{37,"1"},{52,";"}
,{36,"B"},{51,":="},{37,"5"},{52,";"}, {36,"C"},{51,":="},{37,"3"},{52,";"}
,{36,"D"},{51,":="},{37,"4"},{52,";"},{34,"while"},{36,"A"},{53,"<"},{36,"C"}
,{1,"and"},{36,"B"},{57,">"},{36,"D"},{10,"do"},{15,"if"},{36,"A"}
,{56,"="},{37,"1"},{29,"then"},{36,"C"},{51,":="},{36,"C"},{43,"+"},{37,"1"}
,{11,"else"},{34,"while"},{36,"A"},{54,"<="},{36,"D"},{10,"do"},{36,"A"}
,{51,":="},{36,"A"},{41,"*"},{37,"2"},{12,"end"},{46,"."},{0,"$"}
};
Tokens tokens_5{
	{23,"program"},{36,"example5"},{52,","},{33,"var"}
,{36,"A"},{44,","},{36,"B"},{44,","},{36,"C"},{44,","},{36,"D"},{44,","},{36,"W"}
,{50,":"},{17,"integer"},{52,";"},{3,"begin"},{36,"A"},{51,":="},{37,"5"},{52,";"}
,{36,"B"},{51,":="},{37,"4"},{52,";"}, {36,"C"},{51,":="},{37,"3"},{52,";"}
,{36,"D"},{51,":="},{37,"2"},{52,";"},{36,"W"},{51,":="},{37,"1"},{52,";"}
,{15,"if"},{36,"W"},{58,">="},{37,"1"},{29,"then"},{36,"A"},{51,":="}
,{36,"B"},{41,"*"},{36,"C"},{43,"+"},{36,"B"},{48,"/"},{36,"D"},{11,"else"}
,{26,"repeat"},{36,"A"},{51,":="},{36,"A"},{43,"+"},{37,"1"},{32,"until"}
,{36,"A"},{53,"<"},{37,"0"},{12,"end"},{46,"."},  {0,"$"}
};
Tokens tokens{

 };


Token Tk() {
	return tokens[curPos];
}

flag tkid() {
	return static_cast<flag>(tokens[curPos].key);
}

string tkva() {
	return tokens[curPos].value;
}

void backPatch(list<int> ls, int pos)
{
	for (auto p : ls) {
		fourTuples[p - 1][3] = to_string(pos);
	}
}

bool tkis(Token const& tk, initializer_list<flag> flags) {
	flag key = static_cast<flag>(tk.key);
	for (auto const& flag : flags) {
		if (key == flag)return true;
	}
	return false;
}

int emit(string op, string arg1, string arg2, string result)
{
	/*cout << "[" << op << ",  " << arg1 << ",  " 
		<< arg2 << ",  " << result << "]\n";
	*/fourTuples.push_back({ op,arg1,arg2,result });
	return fourTuples.size();
}

int showTuples()
{
	int i = 0;
	for (auto const& fourTuple : fourTuples) {
		cout << i++ << ": [" << fourTuple[0] << ",  " << fourTuple[1] << ",  " 
			<< fourTuple[2] << ",  " << fourTuple[3] << "]\n";
	}
	return fourTuples.size();
}

bool addVar(string name, int value)
{
	if (table.count(name) != 0) { 
		cout << "��������\n";
		system("pause");
		return false; 
	}
	table[name] = value;
	return true;
}

string tmpVar()
{
	string name;
	do {
		name = "T" + to_string(tmpTimes++);
	} while (table.count(name) != 0);
	table[name] = 0;
	return name;
}

