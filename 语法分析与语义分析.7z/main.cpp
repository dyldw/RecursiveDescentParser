﻿#include "func.h"
#include <fstream>
void readTokenString();
int main()
{
	/*
	* 实验二：语法与语义分析
	*
	* //[2021-01-12 19:58]
	* 实验二的这一版用时11小时47分钟
	* 实验二的上一版用时14小时2分钟
	* 好累人啊啊啊啊啊啊啊啊
	*/
	{
	cout << "姓名：董一龙\n";
	cout << "班级：计算机科学与工程二班\n";
	cout << "学号：201930340352\n";
	cout << "请输入测试程序名:( TEST4 或 TEST5 )\n";
	string choice;
	cin >> choice;
	if (choice == "TEST4") {
		tokens = tokens_4;
	}
	else if (choice == "TEST5") {
		tokens = tokens_5;
	}
	else {
		cout << "你打错字了,hhh\n";
		exit(0);
	}
	}
	FUNC_::program();
	showTuples();
}

void readTokenString()
{
	tokens.clear();
	string path;
	cout << "输入Token序列文件路径（就是实验一程序中设定的保存路径）\n";
	cin >> path;
	fstream file(path, ios::in);
	int key;
	string value;
	while (file >> key >> value) {
		tokens.push_back({ key,value });
	}
}
