#include "mathEx.h"

RetType MATH_::E()
{
    RetType ret;
    string name1, name2;
    name1 = I().name;
    switch (tkid())
    {
    case flag::ADD: {
        curPos++;
        name2 = E().name;
        string tmpname = tmpVar();
        emit("+", name1, name2, tmpname);
        ret.name = tmpname;
        break;
    }
    case flag::SUB: {
        curPos++;
        name2 = E().name;
        string tmpname = tmpVar();
        emit("-", name1, name2, tmpVar());
        ret.name = tmpname;
        break;
    }
    default:
        ret.name = name1;
        break;
    }
    return ret;
}

RetType MATH_::E_()
{
    switch (tkid())
    {
    case flag::ADD: {
        PL("E'", "+IE'");
        curPos++;
        I();
        E_();
        break;
    }
    case flag::SUB: {
        PL("E'", "-IE'");
        curPos++;
        I();
        E_();
        break;
    }
    default: {
        if (tkis(Tk(), { flag::R_PARENTHESIS,flag::END,flag::SEMICOLON,
         flag::THEN,flag::DO,flag::UNTIL,flag::ADD,flag::SUB,flag::TERM,flag::ELSE }) ||
            (53 <= tkid() && tkid() <= 58)) {
            PL("E'", "��");
            break;
        }
        else {
            error();
        }
    }
    }
    return RetType();
}

RetType MATH_::I()
{
    RetType ret;
    string name1, name2;
    name1 = D().name;
    switch (tkid())
    {
    case flag::SLASH: {
        curPos++;
        name2 = I().name;
        string result = tmpVar();
        emit("/", name1, name2, result);
        ret.name = result;
        break;
    }
    case flag::ASTERISK: {
        curPos++;
        name2 = I().name;
        string result = tmpVar();
        emit("*", name1, name2, result);
        ret.name = result;
        break;
    }
    default:
        ret.name = name1;
        break;
    }
    return ret;
}

RetType MATH_::I_()
{
    RetType ret;
    switch (tkid())
    {
    case flag::SLASH: {
        PL("I'", "/DI'");
        curPos++;
        D();
        I_();
        break;
    }
    case flag::ASTERISK: {
        PL("I'", "*DI'");
        curPos++;
        D();
        I_();
        break;
    }   
    default: {
        if (tkis(Tk(), { flag::R_PARENTHESIS,flag::END,flag::SEMICOLON,
            flag::THEN,flag::DO,flag::UNTIL,flag::ADD,flag::SUB,flag::TERM,flag::ELSE}) ||
            (53 <= tkid() && tkid() <= 58)) {
            PL("I_", "��");
            break;
        }
        else {
            error();
        }
    }
    }
    return ret;
}

RetType MATH_::D()
{
    RetType ret;
    switch (tkid())
    {
    case flag::SUB: {
        PL("D", "-Q");
        string tmpName = tmpVar();
        curPos++;
        ret = Q();
        emit("@", ret.name, "-", tmpName);
        break;
    }
    default:
        PL("D", "Q");
        ret = Q();
        break;
    }
    return ret;
}

RetType MATH_::Q()
{
    RetType ret;
    switch (tkid())
    {
    case flag::ID: {
        PL("Q", "id");
        ret.name = tkva();
        curPos++;
        break;
    }
    case flag::L_PARENTHESIS: {
        PL("Q", "(E)");
        curPos++;
        ret = E();
        if (tkid() != flag::R_PARENTHESIS) { error(); }
        else curPos++;
        break;
    }
    case flag::INTEGER: {
        PL("Q", "integer");
        ret.name = tkva();
        curPos++;
        break;
    }
    default:
        //cout << tkva();
        error();
        break;
    }
    return ret;
}
