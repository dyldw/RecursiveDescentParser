#include "func.h"

void FUNC_::program()
{
    if (tkid() == flag::PROGRAM) {
        curPos++;
        if (tkid() == flag::ID) {
            emit("program", tkva());
            curPos++;
            if (tkid() == flag::SEMICOLON) {
                curPos++;
                varDeclaration();
                STATE_::compoundStatement();
                if (tkid() == flag::DOT) {
                    emit("sys");
                    cout << "�﷨��ȷ\n";
                }
                else error();
            }
            else error();
        }
        else error();
    }
    else error();
}

RetType FUNC_::varDeclaration()
{
    if (tkid() == flag::VAR) {
        curPos++;
        varDefinition();
    }
    return RetType();
}

RetType FUNC_::varDefinition()
{
    idTable();
    if (tkid() == flag::COLON) {
        curPos++;
        type();
        if (tkid() == flag::SEMICOLON) {
            
            curPos++;
            if (tkid() != flag::BEGIN) {
                varDefinition();
            }
        }
        else error();
    }
    else error();
    return RetType();
}

RetType FUNC_::idTable()
{
    if (tkid() == flag::ID) {
        addVar(tkva());
        curPos++;
        if (tkid() == flag::COMMA) {
            curPos++;
            idTable();
        }
    }
    else error();
    return RetType();
}

RetType FUNC_::type()
{
    switch (tkid())
    {
    case flag::INT: {
        curPos++;
        break;
    }
    case flag::CHAR: {
        curPos++;
        break;
    }
    case flag::REAL: {
        curPos++;
        break;
    }
    default:
        error();
        break;
    }
    return RetType();
}
