#pragma once
#include "common.h"
#include "boolEx.h"
#include "mathEx.h"
#ifndef STATEMENT_H_
#define STATEMENT_H_
namespace STATE_ {
	RetType statement();
	RetType statementTable();
	RetType assignStatement();
	RetType ifStatement();
	RetType whileStatement();
	RetType repeatStatement();
	RetType compoundStatement();
}
#endif // !STATEMENT_H_
